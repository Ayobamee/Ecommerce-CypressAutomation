class LandingPage
{
    

getSpacesLogo()

{

    return  cy.get('[src="/static/media/spaces_logo.508602f0.svg"]')
}

getImageForAgent()

{

    return  cy.get('body:nth-child(2) div:nth-child(2) header.sc-qXFOy.hZbUVv > a:nth-child(1)')
}



getImageProfile()

{

    return  cy.get('body:nth-child(2) div:nth-child(2) header.sc-qXFOy.hZbUVv > a:nth-child(1)')
}


getSaleIcon()

{

    return  cy.get('[href="/actions/shop_sales_add"] > .sc-pQrUA')
}


getShopIcon()

{

    return  cy.get('[href="/actions/shop"] > .sc-pQrUA')
}


getAgentIcon()

{

    return  cy.get('[href="/actions/agents"] > .sc-pQrUA')
}


getMerchantIcon()

{

    return  cy.get('[href="/actions/merchants"] > .sc-pQrUA')
}

}



export default LandingPage;