class LandingPage
{
    

getAddSales()

{

    return  cy.get('[href="/actions/shop_sales_add"] > .sc-pQrUA')
}


getPrompt()
{

    return cy.get('.sc-fzomME > .sc-AxjAm')
}

getSalesAmount() 

{
  return cy.get('.sc-fzoiQi')

}

getNo() {

    return cy.get('.kvyVsR')
}


getPaymentAmount() {

    return cy.get('.ktBnET')
}


getEnableCustIfo() {

    return cy.get('.react-switch-handle')
}

getCustomerPhoneNo() {
    return cy.get('.sc-pYCbY > .sc-fznJRM')
}

getCustomerName() {
    return cy.get('.sc-fznxsB > :nth-child(2)')
}


getMakeSale()   
{
    return cy.get('form > .sc-AxjAm')
}


getAffirmSuccessfulSale()
{
    return cy.get('.Toastify__toast-body')
}

}



export default LandingPage;